# pizza-shop-starter-template
Online Pizza Shop Template to start work on project.all setup has been done you just need to install npm packages with npm install command in clinet directory

#go to terminal or comamnd prompt -> open this within correct path if you folder name is client goto client path or if your folder name is frontend than go to frontend folder path in terminal
#and install node_modules folder use belwo command
# npm install
it will install all the dependencies of node_modules no need to download extra modules
if you stuck please DM on instagram : @technical_update
