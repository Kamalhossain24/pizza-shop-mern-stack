import React from 'react'
import Alert from 'react-bootstrap/Alert';
const Sucess = ({success}) => {
    return <Alert variant="success">{success} </Alert>

}

export default Sucess