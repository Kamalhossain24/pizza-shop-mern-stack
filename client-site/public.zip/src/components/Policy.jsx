import React from 'react'
import { Row, Col, Container} from 'react-bootstrap'
const Policy = () => {
  return (
    <>
    <Container style={{ marginTop: "50px", marginBottom: "50px" }}>
        <h1>Terms and Policy</h1>
        <Row>
            <Col md={10}>
                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, sint!</h6>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. A non libero veritatis iure cumque sed ipsam veniam ad, eos commodi ducimus beatae adipisci illum hic modi velit, fugit vel inventore doloribus saepe, tempora delectus minima ea blanditiis! Eum cumque quod, ea error nobis sed doloribus ab voluptas amet itaque! Repellendus voluptatibus assumenda minus doloremque, beatae molestiae suscipit molestias, temporibus illo accusantium doloribus repellat aut quidem esse vitae nemo fuga excepturi corporis aspernatur obcaecati? Praesentium labore vitae fuga ea quae nulla, voluptatem animi neque! Itaque ipsam optio neque? Dolor error sequi assumenda minus, alias ullam, accusamus, ipsum magni laudantium doloremque beatae!</p>
                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, sint!</h6>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. A non libero veritatis iure cumque sed ipsam veniam ad, eos commodi ducimus beatae adipisci illum hic modi velit, fugit vel inventore doloribus saepe, tempora delectus minima ea blanditiis! Eum cumque quod, ea error nobis sed doloribus ab voluptas amet itaque! Repellendus voluptatibus assumenda minus doloremque, beatae molestiae suscipit molestias, temporibus illo accusantium doloribus repellat aut quidem esse vitae nemo fuga excepturi corporis aspernatur obcaecati? Praesentium labore vitae fuga ea quae nulla, voluptatem animi neque! Itaque ipsam optio neque? Dolor error sequi assumenda minus, alias ullam, accusamus, ipsum magni laudantium doloremque beatae!</p>
                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, sint!</h6>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. A non libero veritatis iure cumque sed ipsam veniam ad, eos commodi ducimus beatae adipisci illum hic modi velit, fugit vel inventore doloribus saepe, tempora delectus minima ea blanditiis! Eum cumque quod, ea error nobis sed doloribus ab voluptas amet itaque! Repellendus voluptatibus assumenda minus doloremque, beatae molestiae suscipit molestias, temporibus illo accusantium doloribus repellat aut quidem esse vitae nemo fuga excepturi corporis aspernatur obcaecati? Praesentium labore vitae fuga ea quae nulla, voluptatem animi neque! Itaque ipsam optio neque? Dolor error sequi assumenda minus, alias ullam, accusamus, ipsum magni laudantium doloremque beatae!</p>
                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, sint!</h6>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. A non libero veritatis iure cumque sed ipsam veniam ad, eos commodi ducimus beatae adipisci illum hic modi velit, fugit vel inventore doloribus saepe, tempora delectus minima ea blanditiis! Eum cumque quod, ea error nobis sed doloribus ab voluptas amet itaque! Repellendus voluptatibus assumenda minus doloremque, beatae molestiae suscipit molestias, temporibus illo accusantium doloribus repellat aut quidem esse vitae nemo fuga excepturi corporis aspernatur obcaecati? Praesentium labore vitae fuga ea quae nulla, voluptatem animi neque! Itaque ipsam optio neque? Dolor error sequi assumenda minus, alias ullam, accusamus, ipsum magni laudantium doloremque beatae!</p>
                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, sint!</h6>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. A non libero veritatis iure cumque sed ipsam veniam ad, eos commodi ducimus beatae adipisci illum hic modi velit, fugit vel inventore doloribus saepe, tempora delectus minima ea blanditiis! Eum cumque quod, ea error nobis sed doloribus ab voluptas amet itaque! Repellendus voluptatibus assumenda minus doloremque, beatae molestiae suscipit molestias, temporibus illo accusantium doloribus repellat aut quidem esse vitae nemo fuga excepturi corporis aspernatur obcaecati? Praesentium labore vitae fuga ea quae nulla, voluptatem animi neque! Itaque ipsam optio neque? Dolor error sequi assumenda minus, alias ullam, accusamus, ipsum magni laudantium doloremque beatae!</p>
            </Col>
        </Row>
    </Container>
    </>
  )
}

export default Policy