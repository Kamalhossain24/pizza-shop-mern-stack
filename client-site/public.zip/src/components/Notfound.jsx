import React from 'react'

const Notfound = () => {
    return (
        <main class="text-center form-signin">
            <img src="/images/404.webp" alt="" />
        </main>
    )
}

export default Notfound